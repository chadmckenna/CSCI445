<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
"http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
	<link rel="stylesheet" type="text/css" href="screen.css" />
	<title>About Us</title>
</head>
<body>
	<div class="index-container">
		<div class="header">
			<div class="logo">
				<img src="images/apple.png" /><h1><a href="index.php">CompassionByTheBook</a></h1>
			</div>
			<div class="nav">
				<ul>
					<li><a href="about.php">About</a></li>
					<li><a href="#">Get Involved</a></li>
					<li><a href="#">Donate</a></li>
					<li><a href="#">Blog</a></li>
				</ul>
			</div>
			<div class="login">
			  <ul>
			    <li><a href="login.php">Login</a></li>
			    <li><a href="signup.php">Sign Up</a></li>
			  </ul>
			</div>
			<div class="clear"></div>
		</div>
		<div class="content">
			<h1>About</h1>
			<h2>What is Compassion by the Book?</h2>
			<blockquote>
				<dt>Compassion [/kuhm-pash-uhn/] <span class="pos">(verb)</span></dt>
				<dd>To care about others beyond ourselves.</dd>
			</blockquote>
			<blockquote>
				<dt>By the book [/bi/ /the/ /book/] <span class="pos">(phrase)</span><dt>
				<dd>Doing it right, the way it should be done.</dd>
			</blockquote>

			<h2>Mission</h2>

			<p>Compassion by the Book (CBTB) educates, empowers, and supports college students to make a positive difference in their communities
			and around the world. CBTB invites students and organizations at colleges and universities to participate in textbook fundraisers to 
			financially support their favorite nonprofit causes and begin to learn a mindset of creative, resourceful giving to the world.</p>

			<h2>Vision and Values (<a href="#">click here to open document</a>)</h2>

			<h2>The History of Compassion by the Book (by Kurtis Griess)</h2>

			<p>The idea behind Compassion by the Book came in August of 2009 when I finally took the initiative to sell my old textbooks. What 
			I found surprised me: they were worth a lot of money and I had been letting them go to waste! I suddenly realized my friends probably
			had unused books too. An internal dialogue began:</p>

			<blockquote>
			<p>Greed: "I bet I could sell their books and make a lot of money."<br />
			Compassion: "No, you should actually try to get some books to raise money for something greater than yourself."</p>
			</blockquote>

			<p>The idea was born.</p>

			<p>I didn't know what to expect, but eight of my friends donated books and we raised $1200 for InterVarsity Christian Fellowship at
			my school (Colorado School of Mines). I began to envision more. How much good could be done through students? I took the idea to other
			students at Mines and Regis University and started textbook fundraisers on behalf of the earthquake in Haiti. All in all, we raised 
			$13,000 between several fundraising initiatives.</p>

			<p>With millions of dollars of books going to waste on bookshelves right now, I decided to start Compassion by the Book. The books 
			are the tool and the compassion of students will change the world.</p>

			<h2>Contact</h2>
			<p>
			2804 W. 111th Loop<br />
			Westminster, CO 80234<br />
			720-432-2282 (CBTB)<br />
			kurtis@compassionbythebook.com<br />
			</p>

			<h2>Legal</h2>

			<p>Compassion by the Book is a 501 (c) (3), non-profit organization. Donations to Compassion by the Book are tax deductible. 
			Compassion by the Book is registered as a charity in the State of Colorado and has its state and local sales tax license for the 
			place it does business (Westminster and Golden). You may request a copy of our legal documents at any time by email.</p>
		</div>
		<div class="blog">
			<h1>Latest News</h1>
			<h2>Update on Fundraisers Underway!</h2>
			<h3>September 1st, 2011</h3>
			<p>There are three groups set up and running textbook fundraisers this semester (as of yesterday it became four!). The total amount 
			fundraised by our students is over $6,000 in the last three weeks alone. This is exciting news for many reasons. 1) Compassion by the Book 
			is fulfilling its mission of empowering college students. 2) A year of planning and organizing is paying ...</p>
			<a id="right" href="#">Continue Reading</a>
			<div class="clear"></div>
		</div>
	</div>
	<div class="footer-container">
		<div class="column-container">
			<div class="column" id="left">
				<h2>About</h2>
				<ul>
					<li><a href="#">What We Do</a></li>
					<li><a href="#">Your Potential</a></li>
					<li><a href="#">Board of Directors</a></li>
					<li><a href="#">FAQs</a></li>
					<li><a href="#">Contact Us</a></li>
					<li>Design by the K4TZ</li>
				<ul>
			</div>
			<div class="column" id="center">
				<h2>Get Involved</h2>
				<ul>
					<li><a href="#">Causes</a></li>
					<li><a href="#">Sign Up</a></li>
				<ul>
			</div>
			<div class="column" id="right">
				<h2>Donate</h2>
				<ul>
					<li><a href="#">Money</a></li>
					<li><a href="#">Books</a></li>
				<ul>
			</div>
			<div class="clear"></div>
		</div>
	</div>
</body>	
</html>